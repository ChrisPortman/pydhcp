Request
========

.. autoclass:: pynetbox.core.query.RequestError
  :members:

.. autoclass:: pynetbox.core.query.ContentError
  :members:

.. autoclass:: pynetbox.core.query.AllocationError
  :members:
