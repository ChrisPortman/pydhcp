Response
========

.. autoclass:: pynetbox.core.response.Record
  :members: